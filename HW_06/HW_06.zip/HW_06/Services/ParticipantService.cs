using AutoMapper;
using HW_06.DTOs.MeetingDTO;
using HW_06.DTOs.ParticipantDTO;
using HW_06.Helpers.Pagination;
using HW_06.Helpers.QueryParameters;
using HW_06.Services.Interfaces;
using HW_06.Validators;
using HW_06.Helpers.Queryable;
using HW_06.Models;
using Microsoft.EntityFrameworkCore;
using HW_06.Validators.Exceptions;

namespace HW_06.Services;

public class ParticipantService : IParticipantService
{
    private readonly DataContext _context;
    private readonly IMapper _mapper;

    private readonly IValidator<ParticipantCreateDTO>
        _createValidator;

    private readonly IValidator<ParticipantUpdateDTO>
        _updateValidator;

    private readonly IValidator<ParticipantPartialUpdateDTO>
        _partialValidator;

    public ParticipantService(
        DataContext context,
        IMapper mapper,
        IValidator<ParticipantCreateDTO> createValidator,
        IValidator<ParticipantUpdateDTO> updateValidator,
        IValidator<ParticipantPartialUpdateDTO> partialValidator)
    {
        _context = context;
        _mapper = mapper;
        _createValidator = createValidator;
        _updateValidator = updateValidator;
        _partialValidator = partialValidator;
    }

    public async Task<PagedResult<ParticipantReadDTO>> GetAllAsync(
        ParticipantQueryParameters parameters)
    {
        ArgumentNullException.ThrowIfNull(parameters);

        IQueryable<Participant> query = _context.Participants
            .AsNoTracking();

        query = query
            .ApplySearch(parameters.SearchLastName)
            .ApplySorting(parameters);

        return await query
            .ToPagedResultAsync<Participant, ParticipantReadDTO>(
                parameters.Page,
                parameters.PageSize,
                _mapper);
    }

    public async Task<ParticipantDetailDTO?> GetByIdAsync(int id)
    {
        var participant = await _context.Participants
            .AsNoTracking()
            .Include(participant =>
                participant.MeetingParticipants)
            .ThenInclude(meetingParticipant =>
                meetingParticipant.Meeting)
            .ThenInclude(meeting =>
                meeting.Room)
            .FirstOrDefaultAsync(participant =>
                participant.ParticipantId == id);

        if (participant is null)
        {
            return null;
        }

        Console.WriteLine(
            $"Participant ID: {participant.ParticipantId}");

        Console.WriteLine(
            $"Meetings count: {participant.MeetingParticipants.Count}");

        return _mapper.Map<ParticipantDetailDTO>(
            participant);
    }
    
    
    public async Task<ParticipantReadDTO> CreateAsync(
        ParticipantCreateDTO dto)
    {
        var validationResult =
            _createValidator.Validate(dto);

        if (!validationResult.IsValid)
        {
            throw new ValidationException(
                validationResult.Errors);
        }

        var normalizedEmail = dto.Email
            .Trim()
            .ToLowerInvariant();

        var emailExists = await _context.Participants
            .AnyAsync(participant =>
                participant.Email.ToLower() ==
                normalizedEmail);

        if (emailExists)
        {
            throw new ValidationException(
                nameof(dto.Email),
                "Учасник із такою електронною поштою вже існує.");
        }

        var participant =
            _mapper.Map<Participant>(dto);

        participant.FirstName =
            participant.FirstName.Trim();

        participant.LastName =
            participant.LastName.Trim();

        participant.Email = normalizedEmail;

        if (participant.Role is not null)
        {
            participant.Role =
                participant.Role.Trim();
        }

        _context.Participants.Add(participant);

        await _context.SaveChangesAsync();

        return _mapper.Map<ParticipantReadDTO>(
            participant);
    }

    public Task<bool> UpdateAsync(
        int id,
        ParticipantUpdateDTO dto)
    {
        throw new NotImplementedException();
    }

    public Task<bool> PartialUpdateAsync(
        int id,
        ParticipantPartialUpdateDTO dto)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<int> DeleteManyAsync(List<int> ids)
    {
        throw new NotImplementedException();
    }

 

    public Task<List<MeetingReadDTO>> GetMeetingsAsync(
        int participantId)
    {
        throw new NotImplementedException();
    }
}