namespace HW_06.DTOs.Meeting;

public class MeetingpartialUpdateDTO
{
    public DateTime DateTime { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}