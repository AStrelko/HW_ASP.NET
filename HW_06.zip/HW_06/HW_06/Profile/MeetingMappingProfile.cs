using AutoMapper;
using HW_06.DTOs.Meeting;
using HW_06.Models;

namespace HW_06.Profile;

public class MeetingMappingProfile: Profile
{
    public MeetingMappingProfile()
    {
        CreateMap<Meeting, MeetingreadDTO>();
        CreateMap<Meeting, MeetingditeylDTO>();
        CreateMap<Meeting, MeetingupdateDTO>();
        CreateMap<Meeting, MeetingpartialUpdateDTO>();
        
    }
}