using HW_06.Services;
using Microsoft.AspNetCore.Mvc;

namespace HW_06.Controllers;

[ApiController]
[Route("api/meetingsDTO")]
public class MeetingControllersDTO: ControllerBase
{
    private readonly MeetingServices _service;
}